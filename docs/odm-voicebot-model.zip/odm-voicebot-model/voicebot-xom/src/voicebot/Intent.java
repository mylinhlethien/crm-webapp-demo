package voicebot;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Intent{
	@XmlElement
    public String intent;
	@XmlElement
    public double confidence;
    
    public Intent(@BusinessName("intent") String intent,@BusinessName("confidence") double confidence) {
    	this();
    	this.intent = intent;
    	this.confidence = confidence;
    }

	public Intent() {
		// TODO Auto-generated constructor stub
	}
}