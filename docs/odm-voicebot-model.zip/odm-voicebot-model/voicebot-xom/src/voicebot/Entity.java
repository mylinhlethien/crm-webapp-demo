package voicebot; 

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Entity{
	@XmlElement
    public String entity;
	@XmlElement
    public String value;
    
    public Entity(@BusinessName("entity") String entity,@BusinessName("value") String value) {
    	this();
    	this.entity = entity;
    	this.value = value;
    }
    
    public Entity() {
		// TODO Auto-generated constructor stub
	}

	public String getEntity() {
    	return this.entity;
    }
    
    public String getValue() {
    	return this.value;
    }
}