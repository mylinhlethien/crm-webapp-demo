package voicebot;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Client {
		@XmlElement	
	 private String _id;
		@XmlElement	
	 private String _rev;
		@XmlElement	
	 private String nomclient;
		@XmlElement	
	 private int numeroclient;
		@XmlElement	
	 ArrayList < Contrat > contrats = new ArrayList < Contrat > ();
		@XmlElement	
	 ArrayList < Historique > historique = new ArrayList < Historique > ();
		@XmlElement	
	 private float Potentiel;
		@XmlElement	
	 private float Sinistralite;
	
	 public Client() {
			// TODO Auto-generated constructor stub
	}

	 public Client(@BusinessName("_id") String _id, @BusinessName("_rev") String _rev,@BusinessName("nomclient") String nomclient, @BusinessName("numeroclient") int numeroclient, @BusinessName("contrats") ArrayList < Contrat > contrats,@BusinessName("historique") ArrayList < Historique > historique, @BusinessName("Potentiel") float Potentiel, @BusinessName("Sinistralite") float Sinistralite) {
		this();	
		this._id = _id;
		this._rev = _rev;
		this.nomclient = nomclient;
		this.numeroclient = numeroclient;
		this.contrats = contrats;
		this.historique = historique;
		this.Potentiel = Potentiel;
		this.Sinistralite = Sinistralite;
	}



	// Getter Methods 
	
	 public String get_id() {
	  return _id;
	 }
	
	 public String get_rev() {
	  return _rev;
	 }
	
	 public String getNomclient() {
	  return nomclient;
	 }
	
	 public int getNumeroclient() {
	  return numeroclient;
	 }
	 
	 public ArrayList <Contrat> getContrats() {
		 return this.contrats;
	 }
	 
	 public ArrayList <Historique> getHistorique() {
		 return this.historique;
	 }
	
	 public float getSinistralite() {
	  return Sinistralite;
	 }
	
	 public float getPotentiel() {
	  return Potentiel;
	 }
	
	 // Setter Methods 
	
	 public void set_id(String _id) {
	  this._id = _id;
	 }
	
	 public void set_rev(String _rev) {
	  this._rev = _rev;
	 }
	
	 public void setNomclient(String nomclient) {
	  this.nomclient = nomclient;
	 }
	
	 public void setNumeroclient(int numeroclient) {
	  this.numeroclient = numeroclient;
	 }
	
	 public void setSinistralite(float Sinistralite) {
	  this.Sinistralite = Sinistralite;
	 }
	
	 public void setPotentiel(float Potentiel) {
	  this.Potentiel = Potentiel;
	 }
}