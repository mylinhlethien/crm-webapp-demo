package voicebot;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Historique{
	@XmlElement	
    String typecontrat;
	@XmlElement	
	String sinistre;
	@XmlElement	
	String date;
    
    public Historique(@BusinessName("typecontrat") String typecontrat,@BusinessName("sinistre") String sinistre ,@BusinessName("date") String date) {
    	this();
    	this.typecontrat = typecontrat;
    	this.sinistre = sinistre;
    	this.date = date;
    }

	public Historique() {
		// TODO Auto-generated constructor stub
	}
}