package voicebot;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Emotion {
	@XmlElement
	public String name;
	@XmlElement
    public double score;
    
 // Constructor
    public Emotion(@BusinessName("name") String name,@BusinessName("score") double score) {
    	this();
    	this.name = name;
    	this.score = score;
    }
    
	 public Emotion() {
		// TODO Auto-generated constructor stub
	}

// Getter Methods 
    public String getEmotion() {
    	return this.name;
    }
    
    public double getScore() {
    	return this.score;
    }
}