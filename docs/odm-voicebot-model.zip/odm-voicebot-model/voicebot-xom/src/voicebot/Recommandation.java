package voicebot;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import ilog.rules.bom.annotations.BusinessName;

@XmlAccessorType(XmlAccessType.FIELD)
public class Recommandation {
	@XmlElement	
    public double urgence;
	@XmlElement	
    public String action;
	@XmlElement	
    public String message;
    
    
    // Constructor
    public Recommandation( @BusinessName("urgence") double urgence, @BusinessName("action") String action, @BusinessName("message") String message) {
    	this();
    	this.urgence = urgence;
    	this.action = action;
    	this.message = message;
    }

    public Recommandation() {
		// TODO Auto-generated constructor stub
	}

	// Getter Methods 
    public double getUrgence() {
    	return this.urgence;
    }
    
    public String getAction() {
    	return this.action;
    }
    
    public String getMessage() {
    	return this.message;
    }


    // Setter Methods 
    
    public void setAction(String newAction) {
    	  this.action = newAction;
    }
    
    public void setMessage(String newMessage) {
  	  this.message = newMessage;
    }

}