package voicebot;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Conversation {
		@XmlElement	
	 private String _id;
		@XmlElement	
	 private String _rev;
		@XmlElement	
	 private int numeroclient;
		@XmlElement	
	 private String id_conversation;
		@XmlElement	
	 ArrayList < Recommandation > recommandations = new ArrayList < Recommandation > ();
	 /*Input InputObject;
	 Output OutputObject;*/
		@XmlElement	
	 ArrayList < Entity > entities = new ArrayList < Entity > ();
		@XmlElement	
	 ArrayList < Intent > intents = new ArrayList < Intent > ();
		@XmlElement	
	 ArrayList < Emotion > emotions = new ArrayList < Emotion > ();

	public Conversation(@BusinessName("_id") String _id, @BusinessName("_rev") String _rev, @BusinessName("numeroclient") int numeroclient, @BusinessName("id_conversation") String id_conversation, @BusinessName("recommandations") ArrayList < Recommandation > recommandations, @BusinessName("entities") ArrayList < Entity > entities, @BusinessName("intents") ArrayList < Intent > intents,  @BusinessName("emotions") ArrayList < Emotion > emotions ) {
		this();
		this._id = _id;
		this._rev = _rev;
		this.numeroclient = numeroclient;
		this.id_conversation = id_conversation;
		this.recommandations = recommandations;
		this.entities = entities;
		this.intents = intents;
		this.emotions = emotions;
	}
	 public Conversation() {
		// TODO Auto-generated constructor stub
	}
	// Getter Methods 
	 
	 public ArrayList <Emotion> getEmotions() {
		 return this.emotions;
	 }
	 
	 public ArrayList <Entity> getEntities() {
		 return this.entities;
	 }
	 
	 public ArrayList <Intent> getIntents() {
		 return this.intents;
	 }
	 
	 public ArrayList <Recommandation> getRecommandations() {
		 return this.recommandations;
	 }
	
	 public String get_id() {
	  return _id;
	 }
	
	 public String get_rev() {
	  return _rev;
	 }
	
	 public float getNumeroclient() {
	  return numeroclient;
	 }
	
	 public String getId_conversation() {
	  return id_conversation;
	 }
	
	 /*public Input getInput() {
	  return InputObject;
	 }
	
	 public Output getOutput() {
	  return OutputObject;
	 }*/
	
	 // Setter Methods 
	
	 public void set_id(String _id) {
	  this._id = _id;
	 }
	
	 public void set_rev(String _rev) {
	  this._rev = _rev;
	 }
	
	 public void setNumeroclient(int numeroclient) {
	  this.numeroclient = numeroclient;
	 }
	
	 public void setId_conversation(String id_conversation) {
	  this.id_conversation = id_conversation;
	 }
	
	 /*public void setInput(Input inputObject) {
	  this.InputObject = inputObject;
	 }
	
	 public void setOutput(Output outputObject) {
	  this.OutputObject = outputObject;
	 }*/
	 
	 /*public static void main(String args[]) {
	 	System.out.println("Hello");
	 	
	 	ArrayList < Recommandation > recolist = new ArrayList <Recommandation>();
	 	Recommandation reco1 = new Recommandation(0.8, "Transfert", "Bonjour");
	 	recolist.add(reco1);
	 	Conversation conv1 = new Conversation("01", recolist);
	 	System.out.println(conv1.getRecommandations().get(0).getMessage());
	 }*/
	 
	}
	
	/*class Output {
	 ArrayList < Object > text = new ArrayList < Object > ();
	
	
	 // Getter Methods 
	
	
	
	 // Setter Methods 
	
	
	}
	class Input {
	 ArrayList < Object > text = new ArrayList < Object > ();
	
	
	 // Getter Methods 
	
	
	
	 // Setter Methods 
	
	
	}
	
	





*/