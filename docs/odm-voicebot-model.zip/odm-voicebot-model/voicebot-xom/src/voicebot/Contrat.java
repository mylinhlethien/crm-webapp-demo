package voicebot;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

//import to be able to use the annotations for the BOM
import ilog.rules.bom.annotations.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Contrat{
	@XmlElement	
    String typecontrat;
	@XmlElement	
	String formule;
	@XmlElement	
	String date;
	@XmlElement	
	int reference;
    
    public Contrat(@BusinessName("typecontrat") String typecontrat,@BusinessName("formule") String formule, @BusinessName("date") String date, @BusinessName("reference") int reference) {
    	this();
    	this.typecontrat = typecontrat;
    	this.formule = formule;
    	this.date = date;
    	this.reference = reference;
    }

	public Contrat() {
		// TODO Auto-generated constructor stub
	}
}